from django.contrib import admin

from calificaciones.models import *

admin.site.register(alumnos)